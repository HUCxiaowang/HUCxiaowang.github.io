var initurl = "http://127.0.0.1:8090/do";
var keyType = 4;
var ppid = 0;//sm3 hash
jQuery.support.cors=true;
var FISECKEY = {
	OpenDevice : function(index, keyType) {
		var handle = 0;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000001',
				index:index
			}, 
			async : false,
			success : function(data){
				handle = data.hdev;
			},
			error :function(err){
				throw new Error(err.statusText+";"+err.responseText);
			}
		});
		return handle;
	},
	CloseDevice : function(hDev) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000002',
				hdevice: hDev
			}, 
			async : false,
			success : function(data){
				
			},
			error :function(err){
				throw new Error(err.statusText+";"+err.responseText);
			}
		});
	},
	OpenByName : function(devName,keyType, devID) {
		var handle = 0;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000003',
				devName: devName,
				devID:devID
			}, 
			async : false,
			success : function(data){
				handle = data.hdev;
			},
			error :function(textStatus){
				throw new Error(err.statusText+";"+err.responseText);
			}
		});
		return handle;
	},
	OpenBySerial : function(devSerial,keyType) {
		var handle = 0;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000004',
				devSerial: devSerial
			}, 
			async : false,
			success : function(data){
				handle = data.hdev;
			},
			error :function(textStatus){
				throw new Error(textStatus.statusText+";"+textStatus.responseText);
			}
		});
		return handle;
	},
	EnumByArray : function() {
		var result = null;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000005'
			}, 
			async : false,
			success : function(data){
				result = data.EnumDeviceNameList;
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
		return result;
	},
	EnumByName : function() {
		var result = null;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000006'
			}, 
			async : false,
			success : function(data){
				result = data.EnumDeviceNameList;
			},
			error :function(err){
				throw new Error(err.statusText+";"+err.responseText);
			}
		});
		return result;
	},
	EnumBySerial : function() {
		var result = null;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000007'
			}, 
			async : false,
			success : function(data){
				result = data.EnumDeviceSerelList;
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
		return result;
	},
	GetInfo : function(hDev,flag,inBuf) {
		var result = null;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000008',
				hdevice: hDev
			}, 
			async : false,
			success : function(data){
				result = data;
				return result;
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
	},
	SetDevName : function(hDev, devName) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000009',
				hdevice:hDev,
				devName:devName
			}, 
			async : false,
			success : function(data){
				if (0 != data.rev) {
					throw new Error("set Devname error"+data.rev);
				}
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
	},
	GetDevName : function(hDev) {
		var result = null;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000063',
				hdevice:hDev
			}, 
			async : false,
			success : function(data){
				result = data.devname;
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
		return result;
	},
	GenRandom : function(hDev, len) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000010',
				hdevice:hDev,
				len:len
			}, 
			async : false,
			success : function(data){
				result = data.ranData;
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
		return result;
	},

	GenRSAKeypair : function(hDev, flag, keyLength, keyNum) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000011',
				hdevice:hDev,
				flag:flag,
				keyNum:keyNum,
				keyLen:keyLength
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("RSA密钥对生成成功")
				} else {
					alert("RSA密钥对生成失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	DelRSAKeypair : function(hDev, keyNum) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000012',
				hdevice:hDev,
				keyNum:keyNum
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("RSA密钥对删除成功")
				} else {
					alert("RSA密钥对删除失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	ImportRSAKey : function(hDev, keyNum, keyLength, flag, vRsakey) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000013',
				hdevice:hDev,
				keyNum:keyNum,
				keyLen:keyLength,
				flag:flag,
				key:vRsakey
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("RSA密钥对导入成功")
				} else {
					alert("RSA密钥对导入失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},
	ExportRSAKey : function(hDev, keyNum) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000014',
				hdevice:hDev,
				keyNum:keyNum
			}, 
			async : false,
			success : function(data){
				result = data.pubkey;
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		return result;
	},
	RSAEncrypt : function(hDev, keyNum, inData) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000015',
				hdevice:hDev,
				keyNum:keyNum,
				inData:inData
			}, 
			async : false,
			success : function(data){
				result = data.enData;
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		return result;
	},

	RSADecrypt : function(hDev, keyNum, inData) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000016',
				hdevice:hDev,
				keyNum:keyNum,
				inData:inData
			}, 
			async : false,
			success : function(data){
				result = data.decData;
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		return result;
	},

	RSASignData : function(hDev, keyNum, inData, vHashAlg) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000017',
				hdevice:hDev,
				keyNum:keyNum,
				inData:inData
			}, 
			async : false,
			success : function(data){
				result = data.sigData;
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		return result;
	},

	RSAVerify : function(hDev, keyNum, vHashAlg, inData, vSignData) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000018',
				hdevice:hDev,
				keyNum:keyNum,
				alg:vHashAlg,
				inData:inData,
				signData:vSignData
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("RSA验签成功")
				} else {
					alert("RSA验签失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	Hash : function(hDev, vHashAlg, inData) {
		var result;
		
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000019',
				hdevice:hDev,
				flag:vHashAlg,
				inData:inData
			}, 
			async : false,
			success : function(data){
				result = data.digest;
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		return result;
	},

	SM3Data : function(hDev, keyNum, inData) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000020',
				hdevice:hDev,
				keyNum:keyNum,
				inData:inData
			}, 
			async : false,
			success : function(data){
				result = data.digest;
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		return result;
	},

	GenECCKeypair : function(hDev, vAlg, vKeyBits, keyNum) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000040',
				hdevice:hDev,
				alg:vAlg,
				keyNum:keyNum,
				keyLen:vKeyBits
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("ECC密钥对生成成功")
				} else {
					alert("ECC密钥对生成失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	DelECCKeypair : function(hDev, keyNum) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000041',
				hdevice:hDev,
				keyNum:keyNum
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("ECC密钥对生成成功")
				} else {
					alert("ECC密钥对生成失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	ImportECCKeypair : function(hDev, keyNum, keyLength, flag, vStrECCPubkey,
			vStrECCPrikey) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000042',
				hdevice:hDev,
				keyNum:keyNum,
				priKey:vStrECCPrikey,
				pubKey:vStrECCPubkey
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("ECC密钥对导入成功")
				} else {
					alert("ECC密钥对导入失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	ExportECCKeypair : function(hDev, keyNum) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000043',
				hdevice:hDev,
				keyNum:keyNum
			}, 
			async : false,
			success : function(data){
				result = data.keyData;
				alert(result);
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		return result;
	},

	ECCEncrypt : function(hDev, alg, keyNum, inData) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000044',
				hdevice:hDev,
				keyNum:keyNum,
				inData:inData
			}, 
			async : false,
			success : function(data){
				result = data.enData;
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		return result;
	},

	ECCDecrypt : function(hDev, alg, keyNum, inData) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000045',
				hdevice:hDev,
				keyNum:keyNum,
				inData:inData
			}, 
			async : false,
			success : function(data){
				result = data.decData;
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		return result;
	},

	ECCSign : function(hDev, alg, keyNum, inData) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000046',
				hdevice:hDev,
				keyNum:keyNum,
				inData:inData,
				alg:alg
			}, 
			async : false,
			success : function(data){
				result = data.sigData;
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		return result;
	},

	ECCVerify : function(hDev, vAlg, keyNum, inData, vSignData) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000047',
				hdevice:hDev,
				keyNum:keyNum,
				alg:vAlg,
				inData:inData,
				signData:vSignData
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("ECC验签成功")
				} else {
					alert("ECC验签失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	ContainerWriteCert : function(hDev, vFlag, vContainerName, vCertData) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000061',
				hdevice:hDev,
				cintainer:vContainerName,
				flag:vFlag,
				cert:vCertData
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("ECC验签成功")
				} else {
					alert("ECC验签失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	ContainerReadCert : function(hDev, vFlag, vContainerName) {
		var result;
		
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000062',
				hdevice:hDev,
				cintainer:vContainerName,
				flag:vFlag
			}, 
			async : false,
			success : function(data){
				result = data.data;
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		return result;
	},

	ContainerEnum : function(hDev) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000052',
				hdevice:hDev
			}, 
			async : false,
			success : function(data){
				result = data.conlist;
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		return result;
	},

	ContainerDelete : function(hDev, vContainerName) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000051',
				hdevice:hDev,
				cintainer:vContainerName
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("容器删除成功")
				} else {
					alert("容器删除失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	USER_Login : function(hDev, vstrPin) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000027',
				hdevice:hDev,
				pin:vstrPin
			}, 
			async : false,
			success : function(data){
				if (0 != data.rev) {
					throw new Error("login error"+data.retnum);
				}
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
	},

	USER_Logout : function(hDevice, vuser) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000028',
				hdevice:hDevice,
				user:vuser
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("用户登出成功")
				} else {
					alert("用户登出失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},
	
	ADMIN_Login : function(hDev, vstrPin) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000064',
				hdevice:hDev,
				pin:vstrPin
			}, 
			async : false,
			success : function(data){
				if (0 != data.rev) {
					throw new Error("admin login error"+data.retnum);
				}
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		}); 
	},
	
	ADMIN_Logout : function(hDevice, vuser) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000028',
				hdevice:hDevice,
				user:vuser
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("管理员登出成功")
				} else {
					alert("管理员登出失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	USER_ChangePin : function(hDev, vflag, vstrOldPin, vstrNewPin) {
		//vflag 1修改操作员口令2修改管理员口令3解锁
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000029',
				hdevice:hDev,
				flag:vflag,
				oldPin:vstrOldPin,
				pin:vstrNewPin
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("用户口令修改成功")
				} else {
					alert("用户口令修改失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	GenKey : function(hDev, vAlg, index) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000022',
				hdevice:hDev,
				alg:vAlg,
				keyNum:index
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("对称密钥生成成功")
				} else {
					alert("对称密钥生成失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	DelKey : function(hDevice, index) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000023',
				hdevice:hDevice,
				keyNum:index
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("密钥删除成功")
				} else {
					alert("密钥删除失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	ImportKey : function(hDevice, viAlg, vstrKey,index) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000021',
				hdevice:hDevice,
				alg:viAlg,
				keyNum:index,
				key:vstrKey
			}, 
			async : false,
			success : function(data){
				if (0 == data.rev) {
					alert("密钥导入成功")
				} else {
					alert("密钥导入失败");
				}
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
	},

	Encrypt : function(hDevice, alg, index, vWorkMode, vstrIn, vstrIv, vstrKey) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000025',
				hdevice:hDevice,
				alg:alg,
				keyNum:index,
				mode:vWorkMode,
				inData:vstrIn,
				iv:vstrIv,
				inKey:vstrKey
			}, 
			async : false,
			success : function(data){
				result = data.enData;
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		
		return result;
	},

	Decrypt : function(hDevice, alg, index, vWorkMode, vstrChiper, vstrIv, vstrKey) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000026',
				hdevice:hDevice,
				alg:alg,
				keyNum:index,
				mode:vWorkMode,
				inData:vstrChiper,
				iv:vstrIv,
				inKey:vstrKey
			}, 
			async : false,
			success : function(data){
				result = data.decData;
			},
			error :function(textStatus){
				alert(textStatus);
			}
		});
		
		return result;
	},

	FILE_Init : function(hDevice) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000031',
				hdevice:hDevice
			}, 
			async : false,
			success : function(data){
				if (0 != data.rev) {
					throw new Error("file init error"+data.rev);
				}
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
	
	},

	FILE_CreateDir : function(hDevice, vstrDir, vdwAccCon) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000032',
				hdevice:hDevice,
				dir:vstrDir,
				acc:vdwAccCon
			}, 
			async : false,
			success : function(data){
				if (0 != data.rev) {
					throw new Error("create dir error"+data.rev);
				}
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
	},

	FILE_CreateFile : function(hDevice, vstrDir, vstrfile, vdwSize, vdwAccCon) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000034',
				hdevice:hDevice,
				dir:vstrDir,
				file:vstrfile,
				size:vdwSize,
				acc:vdwAccCon
			}, 
			async : false,
			success : function(data){
				if (0 != data.rev) {
					throw new Error("create file error"+data.rev);
				}
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
	},

	FILE_DeleteDir : function(hDevice, vstrDir) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000033',
				hdevice:hDevice,
				dir:vstrDir
			}, 
			async : false,
			success : function(data){
				if (0 != data.rev) {
					throw new Error("delete dir error"+data.rev);
				}
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
	},

	FILE_DeleteFile : function(hDevice, vstrDir, vstrfile) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000037',
				hdevice:hDevice,
				dir:vstrDir,
				file:vstrfile
			}, 
			async : false,
			success : function(data){
				if (0 != data.rev) {
					throw new Error("delete file error"+data.rev);
				}
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
	},

	FILE_EnmuDir : function(hDevice, vstrDir) {
		var dirlist = "";
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000038',
				hdevice:hDevice,
				dir:vstrDir
			}, 
			async : false,
			success : function(data){
				if (0 != data.rev) {
					throw new Error("enum dir error"+data.rev);
				}
				dirlist = data.data; 
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
		return dirlist;
	},
	
	FILE_EnmuFile : function(hDevice, vstrDir) {
		var dirlist = "";
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000039',
				hdevice:hDevice,
				dir:vstrDir
			}, 
			async : false,
			success : function(data){
				if (0 != data.rev) {
					throw new Error("enum file error"+data.rev);
				}
				dirlist = data.data; 
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
		return dirlist;
	},

	FILE_ReadFile : function(hDevice, vstrDir, vstrfile, vdwOffSet, vdwSize) {
		var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000035',
				hdevice:hDevice,
				dir:vstrDir,
				file:vstrfile,
				offset:vdwOffSet,
				size:vdwSize
			}, 
			async : false,
			success : function(data){
				if (0 != data.rev) {
					throw new Error("read file error"+data.rev);
				}
				result = data.data;
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
		return result;
	},

	FILE_WriteFile : function(hDevice, vstrDir, vstrfile, vdwOffSet, vdwSize,
			vstrData) {
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000036',
				hdevice:hDevice,
				dir:vstrDir,
				file:vstrfile,
				offset:vdwOffSet,
				size:vdwSize,
				input:vstrData
			}, 
			async : false,
			success : function(data){
				if (0 != data.rev) {
					throw new Error("write file error"+data.rev);
				}
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
	},

	FILE_GetInfo : function(hDevice, vstrDir, vstrfile) {

	},

	getSerialAndSubjects : function(hDevice) {
	var result;
		$.ajax({
			url: initurl,
			type : "post",
			data : {
				order: '01000054',
				hdevice:hDevice
			}, 
			async : false,
			success : function(data){
				result = data.sersublist;
			},
			error :function(textStatus){
				throw new Error(textStatus);
			}
		});
		return result;
	}
}


